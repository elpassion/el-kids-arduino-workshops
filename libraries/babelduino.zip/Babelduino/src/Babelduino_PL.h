#ifndef BABELDUINO_PL_H
#define BABELDUINO_PL_H

#define podaj
#define niech auto
#define czy boolean
#define taknie boolean
#define liczba int
#define liczbe int
#define procedura void
#define nic void
#define czekaj delay
#define stop break
#define w_przypadku case
#define wykonuj do
#define w_przeciwnym_razie else
#define powtorz for
#define jezeli if
#define wynik return
#define skocz_do goto
#define wybierz switch
#define dopoki while
#define ustaw setup
#define powtarzaj loop
#define nie not
#define lub or
#define i and

#endif /* BABELDUINO_PL_H */
